﻿using System;
using System.Collections.Generic;
using System.Timers;
using Rocket.API.Serialisation;
using Rocket.Core;
using Rocket.Core.Utils;
using Rocket.Unturned.Chat;
using Rocket.Unturned.Player;
using SDG.Unturned;
using UnityEngine;

namespace LonelyRobbery
{
	public class PickpocketComponent : MonoBehaviour
	{
		// Token: 0x17000001 RID: 1
		// (get) Token: 0x06000001 RID: 1 RVA: 0x00002050 File Offset: 0x00000250
		// (set) Token: 0x06000002 RID: 2 RVA: 0x00002058 File Offset: 0x00000258
		public Timer Timer { get; set; }

		// Token: 0x17000002 RID: 2
		// (get) Token: 0x06000003 RID: 3 RVA: 0x00002061 File Offset: 0x00000261
		// (set) Token: 0x06000004 RID: 4 RVA: 0x00002069 File Offset: 0x00000269
		public UnturnedPlayer Pickpocket { get; set; }

		// Token: 0x17000003 RID: 3
		// (get) Token: 0x06000005 RID: 5 RVA: 0x00002072 File Offset: 0x00000272
		// (set) Token: 0x06000006 RID: 6 RVA: 0x0000207A File Offset: 0x0000027A
		public UnturnedPlayer Victim { get; set; }

		// Token: 0x06000007 RID: 7 RVA: 0x00002084 File Offset: 0x00000284
		public void Initialize(UnturnedPlayer pickpocket, UnturnedPlayer victim, PickpocketPlugin pluginInstance)
		{
			this.pluginInstance = pluginInstance;
			this.Pickpocket = pickpocket;
			this.Victim = victim;
			this.Timer = new Timer(pluginInstance.Configuration.Instance.RobberyTime * 1000.0);
			this.Timer.AutoReset = false;
			this.Timer.Elapsed += this.Timer_Elapsed;
			this.Timer.Start();
		}

		// Token: 0x06000008 RID: 8 RVA: 0x00002100 File Offset: 0x00000300
		private void FixedUpdate()
		{
			bool flag = this.Timer != null;
			if (flag)
			{
				Player playerFromHits = RaycastHelper.GetPlayerFromHits(this.Pickpocket.Player, this.pluginInstance.Configuration.Instance.MaxDistance);
				bool flag2 = playerFromHits != this.Victim.Player;
				if (flag2)
				{
					UnturnedChat.Say(this.Pickpocket.CSteamID, this.pluginInstance.Translate("FAIL", new object[]
					{
						this.Victim.CharacterName
					}), this.pluginInstance.MessageColor);
					bool notifyVictimOnFail = this.pluginInstance.Configuration.Instance.NotifyVictimOnFail;
					if (notifyVictimOnFail)
					{
						UnturnedChat.Say(this.Victim.CSteamID, this.pluginInstance.Translate("NOTIFY_FAIL", new object[]
						{
							this.Pickpocket.CharacterName
						}), this.pluginInstance.MessageColor);
					}
                    UnityEngine.Object.Destroy(this);
					this.Timer.Dispose();
				}
			}
		}

		// Token: 0x06000009 RID: 9 RVA: 0x0000220C File Offset: 0x0000040C
		private void Timer_Elapsed(object sender, ElapsedEventArgs e)
		{
			TaskDispatcher.QueueOnMainThread(delegate ()
			{
				UnturnedChat.Say(this.Pickpocket.CSteamID, this.pluginInstance.Translate("SUCCESS", new object[]
				{
					this.Victim.CharacterName
				}), this.pluginInstance.MessageColor);
				bool notifyVictimOnSuccess = this.pluginInstance.Configuration.Instance.NotifyVictimOnSuccess;
				if (notifyVictimOnSuccess)
				{
					UnturnedChat.Say(this.Victim.CSteamID, this.pluginInstance.Translate("NOTIFY_SUCCESS", new object[]
					{
						this.Pickpocket.CharacterName
					}), this.pluginInstance.MessageColor);
				}
				List<InventoryItem> list = new List<InventoryItem>();
				for (byte b = 0; b < 6; b += 1)
				{
					for (byte b2 = 0; b2 < this.Victim.Inventory.items[(int)b].getItemCount(); b2 += 1)
					{
						bool flag = this.Victim.Inventory.items[(int)b].getItem(b2) != null;
						if (flag)
						{
							list.Add(new InventoryItem(this.Victim.Inventory.items[(int)b].getItem(b2), b, b2));
						}
					}
				}
				bool flag2 = list.Count <= 0;
				if (flag2)
				{
					UnturnedChat.Say(this.Pickpocket.CSteamID, this.pluginInstance.Translate("NOTHING", new object[]
					{
						this.Victim.CharacterName
					}), this.pluginInstance.MessageColor);
				}
				else
				{
					System.Random random = new System.Random();
					InventoryItem inventoryItem = list[random.Next(list.Count)];
					this.Victim.Inventory.removeItem(inventoryItem.Page, inventoryItem.Index);
					this.Pickpocket.Inventory.forceAddItem(inventoryItem.Item.item, true);
					bool notifyPolice = this.pluginInstance.Configuration.Instance.NotifyPolice;
					if (notifyPolice)
					{
						RocketPermissionsGroup group = R.Permissions.GetGroup(this.pluginInstance.Configuration.Instance.PoliceGroupId);
						Provider.clients.ForEach(delegate (SteamPlayer client)
						{
							bool flag3 = group.Members.Contains(client.playerID.steamID.m_SteamID.ToString()) || client.isAdmin;
							if (flag3)
							{
								UnturnedChat.Say(client.playerID.steamID, this.pluginInstance.Translate("NOTIFY_POLICE", new object[]
								{
									this.Pickpocket.CharacterName,
									inventoryItem.Item.interactableItem.asset.itemName,
									inventoryItem.Item.item.id,
									this.Victim.CharacterName
								}), this.pluginInstance.MessageColor);
							}
						});
					}
				}
				UnityEngine.Object.Destroy(this);
			});
		}

		// Token: 0x0600000A RID: 10 RVA: 0x00002221 File Offset: 0x00000421
		private void OnDestroy()
		{
			this.Timer.Elapsed -= this.Timer_Elapsed;
		}

		// Token: 0x04000001 RID: 1
		private PickpocketPlugin pluginInstance;
	}
}
