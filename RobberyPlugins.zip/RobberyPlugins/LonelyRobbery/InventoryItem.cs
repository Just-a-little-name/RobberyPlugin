﻿using System;
using SDG.Unturned;

namespace LonelyRobbery
{
	// Token: 0x02000004 RID: 4
	public class InventoryItem
	{
		public InventoryItem(ItemJar item, byte page, byte index)
		{
			this.Item = item;
			this.Page = page;
			this.Index = index;
		}

		public ItemJar Item { get; set; }

		public byte Page { get; set; }

		public byte Index { get; set; }
	}
}
