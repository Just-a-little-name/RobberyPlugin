﻿using System;
using SDG.Unturned;
using System.Collections;
using UnityEngine;



namespace LonelyRobbery
{
	public class RaycastHelper : MonoBehaviour
	{
		// Token: 0x0600000D RID: 13 RVA: 0x000024C8 File Offset: 0x000006C8
		public static Player GetPlayerFromHits(Player caller, float maxDistance)
		{
			RaycastHit[] array;
			array = Physics.RaycastAll(new Ray(caller.look.aim.position, caller.look.aim.forward), maxDistance, RayMasks.PLAYER_INTERACT | 512);
			Player result = null;
			for (int i = 0; i < array.Length; i++)
			{
				Player componentInParent = array[i].transform.GetComponentInParent<Player>();
				bool flag = componentInParent != caller;
				if (flag)
				{
					result = componentInParent;
					break;
				}
			}
			return result;
		}
	}
}
