﻿using System;
using Rocket.API;

namespace LonelyRobbery
{
	public class PickpocketConfiguration : IRocketPluginConfiguration, IDefaultable
	{
		// Token: 0x17000007 RID: 7
		// (get) Token: 0x06000016 RID: 22 RVA: 0x000025AE File Offset: 0x000007AE
		// (set) Token: 0x06000017 RID: 23 RVA: 0x000025B6 File Offset: 0x000007B6
		public double RobberyTime { get; set; }

		// Token: 0x17000008 RID: 8
		// (get) Token: 0x06000018 RID: 24 RVA: 0x000025BF File Offset: 0x000007BF
		// (set) Token: 0x06000019 RID: 25 RVA: 0x000025C7 File Offset: 0x000007C7
		public double RobberyCooldown { get; set; }

		// Token: 0x17000009 RID: 9
		// (get) Token: 0x0600001A RID: 26 RVA: 0x000025D0 File Offset: 0x000007D0
		// (set) Token: 0x0600001B RID: 27 RVA: 0x000025D8 File Offset: 0x000007D8
		public bool NotifyVictimOnSuccess { get; set; }

		// Token: 0x1700000A RID: 10
		// (get) Token: 0x0600001C RID: 28 RVA: 0x000025E1 File Offset: 0x000007E1
		// (set) Token: 0x0600001D RID: 29 RVA: 0x000025E9 File Offset: 0x000007E9
		public bool NotifyVictimOnFail { get; set; }

		// Token: 0x1700000B RID: 11
		// (get) Token: 0x0600001E RID: 30 RVA: 0x000025F2 File Offset: 0x000007F2
		// (set) Token: 0x0600001F RID: 31 RVA: 0x000025FA File Offset: 0x000007FA
		public bool UsePermissions { get; set; }

		// Token: 0x1700000C RID: 12
		// (get) Token: 0x06000020 RID: 32 RVA: 0x00002603 File Offset: 0x00000803
		// (set) Token: 0x06000021 RID: 33 RVA: 0x0000260B File Offset: 0x0000080B
		public bool NotifyPolice { get; set; }

		// Token: 0x1700000D RID: 13
		// (get) Token: 0x06000022 RID: 34 RVA: 0x00002614 File Offset: 0x00000814
		// (set) Token: 0x06000023 RID: 35 RVA: 0x0000261C File Offset: 0x0000081C
		public string PoliceGroupId { get; set; }

		// Token: 0x1700000E RID: 14
		// (get) Token: 0x06000024 RID: 36 RVA: 0x00002625 File Offset: 0x00000825
		// (set) Token: 0x06000025 RID: 37 RVA: 0x0000262D File Offset: 0x0000082D
		public float MaxDistance { get; set; }

		// Token: 0x1700000F RID: 15
		// (get) Token: 0x06000026 RID: 38 RVA: 0x00002636 File Offset: 0x00000836
		// (set) Token: 0x06000027 RID: 39 RVA: 0x0000263E File Offset: 0x0000083E
		public bool UseBypass { get; set; }

		// Token: 0x17000010 RID: 16
		// (get) Token: 0x06000028 RID: 40 RVA: 0x00002647 File Offset: 0x00000847
		// (set) Token: 0x06000029 RID: 41 RVA: 0x0000264F File Offset: 0x0000084F
		public string MessageColor { get; set; }

		// Token: 0x17000011 RID: 17
		// (get) Token: 0x0600002A RID: 42 RVA: 0x00002658 File Offset: 0x00000858
		// (set) Token: 0x0600002B RID: 43 RVA: 0x00002660 File Offset: 0x00000860
		public string Kirichek { get; set; }

		// Token: 0x0600002C RID: 44 RVA: 0x0000266C File Offset: 0x0000086C
		public void LoadDefaults()
		{
			this.RobberyTime = 2.0;
			this.RobberyCooldown = 30.0;
			this.NotifyVictimOnSuccess = false;
			this.NotifyVictimOnFail = true;
			this.UsePermissions = false;
			this.NotifyPolice = false;
			this.PoliceGroupId = "mysar";
			this.MaxDistance = 5f;
			this.UseBypass = true;
			this.MessageColor = "yellow";
			this.Kirichek = "By";
		}
	}
}
